package com.sinelynx.grindingrobot.feature.device.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.os.SystemClock
import android.graphics.BitmapFactory
import com.sinelynx.grindingrobot.core.data.state.AppState
import com.sinelynx.grindingrobot.core.model.state.MapImageStream
import com.sinelynx.grindingrobot.core.model.state.MapImagePayload
import com.sinelynx.grindingrobot.core.model.state.MapRegionPointStream
import com.sinelynx.grindingrobot.core.model.state.TaskMapDisplayStream
import com.sinelynx.grindingrobot.core.model.state.TaskPathPayload
import com.sinelynx.grindingrobot.core.model.state.TaskPathStream
import com.sinelynx.grindingrobot.core.tcp.DeviceCommandResult
import com.sinelynx.grindingrobot.core.util.log.LogUtils
import com.sinelynx.grindingrobot.core.model.state.TaskSchedulerStream
import com.sinelynx.grindingrobot.core.model.state.TaskRuntimeSettingsPayload
import com.sinelynx.grindingrobot.core.tcp.TcpManager
import com.sinelynx.grindingrobot.core.tcp.ConnectionState
import com.sinelynx.grindingrobot.core.util.toast.ToastUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.combine
import com.sinelynx.grindingrobot.core.model.state.MapCatalogStream
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withTimeoutOrNull
import com.sinelynx.grindingrobot.core.model.state.TaskExecutionHistoryRecordPayload
import com.sinelynx.grindingrobot.core.model.state.DeviceWorkTimeStatisticsPayload
import com.sinelynx.grindingrobot.core.model.state.TaskHistoryRequestGate
import java.util.Locale
import sl_link.SlLink
import com.sinelynx.grindingrobot.feature.map.ui.grindingDiscLocalCenter
import kotlin.math.roundToInt

/**
 * 设备页汇合两类独立状态：0x0504 的实时任务/位置数据，以及 taskMapController 的地图材料。
 * mapImageBytes/mapTransform/plannedPath 是提供给现有绘制组件的适配字段；taskMap 保留完整
 * 区域、选区、临时禁区和加载错误，不是另一套网络请求结果。
 */
data class DeviceStatusUiState(
    val taskState: DeviceTaskUiState = DeviceTaskUiState.IDLE,
    val currentTaskId: String = "",
    val mapAvailable: Boolean = false,
    val mapName: String = "暂无地图",
    val navigationStatus: String = "空闲",
    val navRadarStatus: String = "—",
    val obstacleRadarStatus: String = "-",
    val localizationQualityAvailable: Boolean = false,
    val localizationQuality: Int = 0,
    val straightSpeedText: String = "0.0 m/s",
    val grindRpmText: String = "0 rpm",
    val configuredRunSpeed: Float? = null,
    val configuredDiscSpeedRpm: Int? = null,
    val runtimeSettings: TaskRuntimeSettingsPayload? = null,
    val runtimeEditor: TaskRuntimeField? = null,
    val runtimeInput: String = "",
    val runtimeLoading: Boolean = false,
    val runtimeApplying: Boolean = false,
    val runtimeError: String? = null,
    val navigationPauseNotice: NavigationPauseNotice? = null,
    val totalTaskAreaText: String = "0.00m²",
    val doneTaskAreaText: String = "0.00m²",
    val remainTaskAreaText: String = "0.00m²",
    val todayAreaText: String = "-",
    val totalAreaText: String = "-",
    val todayWorkTimeText: String = "-",
    val totalWorkTimeText: String = "-",
    val statisticsError: String? = null,
    val statisticsNotice: String? = null,
    val remainTimeText: String = "未知",
    val mapImageBytes: ByteArray? = null,
    val mapTransform: TaskMapTransformUiState? = null,
    val plannedPath: TaskPathPayload? = null,
    val taskMap: DeviceTaskMapState = DeviceTaskMapState(),
    val reportedPathVersion: Int = 0,
    val trajectory: TaskTrajectorySnapshot = TaskTrajectorySnapshot.Empty,
    val showCameraOverlay: Boolean = false,
    val videoStreamUrl: String? = null,
    val robotWidth: Double? = null,
    val robotLength: Double? = null,
    val robotFootprint: List<AppState.FootprintPoint> = emptyList()
)

enum class DeviceTaskUiState {
    IDLE,
    READY,
    RUNNING,
    PAUSED
}

/** 一次设备上报的位置（米、度）；lineColorArgb 由当前研磨遍次决定，不是规划路径的 scope 色。 */
data class TaskPoseUiItem(
    val x: Float,
    val y: Float,
    val headingDeg: Float,
    val lineColorArgb: Int
)

/**
 * 将地图原始几何传给绘制层。width/height 是逻辑地图尺寸，不一定等于解码图片尺寸。
 * headingDeg 属于地图坐标朝向；totalRotationDeg 才是展示旋转，两者不可互相替代。
 * previewScaleX/Y 保留元数据，当前投影使用实际图片/逻辑地图尺寸比例，不再重复相乘。
 */
data class TaskMapTransformUiState(
    val width: Int,
    val height: Int,
    val resolution: Float,
    val originX: Double,
    val originY: Double,
    val headingDeg: Float,
    val previewScaleX: Float,
    val previewScaleY: Float,
    val alignmentYawDeg: Float = 0f,
    val rotationAlignmentDeltaDeg: Float = 0f
) {
    val totalRotationDeg: Float
        get() = alignmentYawDeg + rotationAlignmentDeltaDeg
}

internal fun DeviceStatusUiState.afterTaskStopped(): DeviceStatusUiState {
    return copy(
        taskState = DeviceTaskUiState.IDLE,
        navigationStatus = "空闲",
        runtimeSettings = null,
        runtimeEditor = null,
        runtimeLoading = false,
        runtimeApplying = false,
        navigationPauseNotice = null,
        plannedPath = null,
        reportedPathVersion = 0,
        trajectory = TaskTrajectorySnapshot.Empty
    )
}

/**
 * 设备页状态汇合入口。先读 taskStatusReport collector（任务、统计、轨迹），再读
 * taskMapController.state collector（底图/区域/规划线），即可看清实时数据与缓存的分工。
 * 前者只把任务身份和路径版本通知控制器；后者不覆盖机器人位置、进度或剩余时间。
 * 网络补取是否发生由控制器决策，页面可见性由 DeviceStatusScreen 生命周期回调传入。
 */
@HiltViewModel
class DeviceStatusViewModel @Inject constructor(
    private val appState: AppState,
    private val tcpManager: TcpManager
) : ViewModel() {

    private companion object {
        const val CLICK_DEBOUNCE_MS = 300L
    }

    private enum class PendingTaskCommandType {
        START,
        STOP,
        PAUSE,
        RESUME
    }

    private val _uiState = MutableStateFlow(DeviceStatusUiState())
    val uiState: StateFlow<DeviceStatusUiState> = _uiState.asStateFlow()
    private var lastCommandClickAtMs: Long = 0L
    private var commandGeneration = 0L
    private val pendingTaskCommands = mutableSetOf<PendingTaskCommandType>()
    private var runtimeSettingsJob: Job? = null
    private var statisticsVisible = false
    private var statisticsRefreshJob: Job? = null
    private var statisticsRequestJob: Job? = null
    private var statisticsRecords: List<TaskExecutionHistoryRecordPayload>? = null
    private var statisticsWorkTime: DeviceWorkTimeStatisticsPayload? = null
    private val trajectoryAccumulator = TaskTrajectoryAccumulator()
    private var trajectoryDiscLocalX: Float? = null
    private var trajectoryDiscLocalY: Float? = null
    private var lastTrajectoryReportAtMs = 0L
    private var navigationWasConnected = false
    private var navigationConnectedAtMs = Long.MAX_VALUE
    private val navigationPauseTracker = NavigationPauseNoticeTracker()
    // 只订阅新路径结果流，不让其他页面的历史成功路径提前结束本轮等待。
    private val taskMapController = DeviceTaskMapController(
        scope = viewModelScope, cache = TaskMapDisplayStream.cache,
        frames = MapImageStream.frames, regions = MapRegionPointStream.responses, paths = TaskPathStream.results,
        sendMap = { tcpManager.requestMapSnapshot(it) },
        sendRegions = { tcpManager.requestMapRegionPoints(it) },
        sendPath = { mapId, taskId, requestId ->
            // 状态展示不强制重规划；false 允许设备复用有效缓存，不意味着协议绝对只读。
            tcpManager.requestPathPointPlan(taskId = taskId, mapId = mapId, requestId = requestId, forceReplan = false)
        },
        decodeSize = { bytes ->
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { bitmap ->
                (bitmap.width to bitmap.height).also { bitmap.recycle() }
            }
        }
    )

    init {
        viewModelScope.launch {
            while (isActive) {
                delay(500L)
                val received = appState.runtimeTaskState.value.receivedAtElapsedMs
                if (received <= 0L || SystemClock.elapsedRealtime() - received > 3_000L) {
                    _uiState.update { it.copy(navRadarStatus = "状态过期", obstacleRadarStatus = "状态过期",
                        localizationQualityAvailable = false) }
                }
            }
        }
        viewModelScope.launch {
            appState.chassisSettings.collect { settings ->
                _uiState.update {
                    it.copy(
                        configuredRunSpeed = settings?.runSpeed,
                        configuredDiscSpeedRpm = settings?.discSpeedRpm
                    )
                }
            }
        }
        viewModelScope.launch {
            combine(appState.runtimeTaskState, tcpManager.getConnectionStateFlow()) { runtime, connection ->
                runtime to connection
            }.collect { (runtime, connection) ->
                val connected = connection == ConnectionState.CONNECTED
                if (navigationWasConnected && !connected) {
                    val broken = trajectoryAccumulator.breakContinuity()
                    lastTrajectoryReportAtMs = 0L
                    _uiState.update { it.copy(trajectory = broken) }
                }
                if (connected && !navigationWasConnected) navigationConnectedAtMs = SystemClock.elapsedRealtime()
                navigationWasConnected = connected
                val hasCurrentReport = connected && runtime.receivedAtElapsedMs >= navigationConnectedAtMs &&
                    SystemClock.elapsedRealtime() - runtime.receivedAtElapsedMs <= 3_000L
                _uiState.update { current ->
                    current.copy(
                        navRadarStatus = if (!hasCurrentReport) "—" else navigationRadarLabel(
                            runtime.localizationReady, runtime.localizationStatusReason,
                            runtime.localizationPoseAvailable
                        ),
                        obstacleRadarStatus = if (!hasCurrentReport) "状态过期" else if (runtime.collisionImminent) "检测到障碍/数据异常" else "正常",
                        straightSpeedText = "${runtime.vehicleSpeedMps} m/s",
                        grindRpmText = "${runtime.discSpeedRpm} rpm",
                        localizationQualityAvailable = hasCurrentReport && runtime.localizationQualityAvailable,
                        localizationQuality = runtime.localizationQuality
                    )
                }
                refreshNavigationPauseNotice()
            }
        }

        viewModelScope.launch {
            appState.videoStreamInfo.collect { info ->
                _uiState.update {
                    it.copy(
                        videoStreamUrl = info?.streamUrl?.takeIf { url -> url.isNotBlank() }
                    )
                }
            }
        }

        viewModelScope.launch {
            appState.robotSettings.collect { settings ->
                val disc = grindingDiscLocalCenter(settings?.footprint.orEmpty(), settings?.robotLength)
                trajectoryDiscLocalX = disc?.x
                trajectoryDiscLocalY = disc?.y
                val geometry = trajectoryAccumulator.configure(disc?.x, disc?.y)
                _uiState.update { current ->
                    current.copy(
                        robotWidth = settings?.robotWidth,
                        robotLength = settings?.robotLength,
                        robotFootprint = settings?.footprint.orEmpty(),
                        trajectory = geometry
                    )
                }
            }
        }

        viewModelScope.launch {
            // 不受地图 loading 状态控制；收到状态上报就更新，实际频率由嵌入式决定。
            TaskSchedulerStream.taskStatusReport.collect { payload ->
                payload ?: return@collect
                val rpp = payload.message.substringAfter("rpp:", "").takeIf { it.isNotBlank() }
                if (rpp != null) _uiState.update { it.copy(obstacleRadarStatus = collisionDetailLabel(rpp)) }
                val reportTaskId = payload.taskId
                val taskState = payload.toTaskUiState()
                val taskStateChanged = taskState != _uiState.value.taskState
                val taskIdentityChanged = reportTaskId != _uiState.value.currentTaskId
                val taskEnded = taskState == DeviceTaskUiState.IDLE &&
                    _uiState.value.taskState != DeviceTaskUiState.IDLE
                val runtimeInvalidated = reportTaskId != _uiState.value.currentTaskId ||
                    taskState !in setOf(DeviceTaskUiState.RUNNING, DeviceTaskUiState.PAUSED)
                if (runtimeInvalidated) runtimeSettingsJob?.cancel()
                if (taskState != _uiState.value.taskState || reportTaskId != _uiState.value.currentTaskId) {
                    LogUtils.i("TaskControl", "UI status taskId=$reportTaskId state=${payload.stateValue} label=$taskState")
                }
                val receivedAt = SystemClock.elapsedRealtime()
                if (lastTrajectoryReportAtMs > 0L && receivedAt - lastTrajectoryReportAtMs > 3_000L) {
                    trajectoryAccumulator.breakContinuity()
                }
                val nextTrajectory = trajectoryAccumulator.accept(reportTaskId, taskState, payload.toPoseItem(),
                    trajectoryDiscLocalX, trajectoryDiscLocalY)
                lastTrajectoryReportAtMs = if (taskState == DeviceTaskUiState.IDLE) 0L else receivedAt
                _uiState.update { current ->
                    val doneTaskArea = payload.totalWorkArea - payload.remainWorkArea
                    val taskChanged = reportTaskId.isNotBlank() && reportTaskId != current.currentTaskId
                    current.copy(
                        taskState = taskState,
                        navigationPauseNotice = current.navigationPauseNotice.takeIf {
                            taskState != DeviceTaskUiState.IDLE && !taskChanged
                        },
                        runtimeSettings = if (runtimeInvalidated) null else current.runtimeSettings,
                        runtimeEditor = if (runtimeInvalidated) null else current.runtimeEditor,
                        runtimeLoading = if (runtimeInvalidated) false else current.runtimeLoading,
                        runtimeApplying = if (runtimeInvalidated) false else current.runtimeApplying,
                        currentTaskId = payload.taskId,
                        navigationStatus = taskState.navigationLabel(),
                        totalTaskAreaText = formatAreaM2(payload.totalWorkArea),
                        doneTaskAreaText = formatAreaM2(doneTaskArea),
                        remainTaskAreaText = formatAreaM2(payload.remainWorkArea),
                        remainTimeText = formatRemainTimeS(payload.remainTimeS),
                        mapImageBytes = if (taskChanged) null else current.mapImageBytes,
                        mapTransform = if (taskChanged) null else current.mapTransform,
                        mapAvailable = if (taskChanged) false else current.mapAvailable,
                        mapName = if (taskChanged) "暂无地图" else current.mapName,
                        plannedPath = when {
                            taskState == DeviceTaskUiState.IDLE -> null
                            taskChanged -> null
                            else -> current.plannedPath
                        },
                        reportedPathVersion = if (taskState == DeviceTaskUiState.IDLE) 0 else payload.pathVersion,
                        trajectory = nextTrajectory
                    )
                }
                // 高频位置上报会多次到达这里，但相同任务/路径版本不会因此反复取图。
                taskMapController.onTask(
                    taskId = reportTaskId.takeIf { taskState != DeviceTaskUiState.IDLE },
                    pathVersion = payload.pathVersion
                )
                if (runtimeInvalidated || taskStateChanged) refreshRuntimeSettings()
                refreshNavigationPauseNotice()
                if (taskEnded || taskStateChanged || taskIdentityChanged) refreshStatistics()
                if (taskStateChanged || taskIdentityChanged) updateStatisticsDisplay()
            }
        }

        viewModelScope.launch {
            // 地图加载结果只更新显示材料。规划阶段面积/耗时不能覆盖上方实时任务统计。
            combine(taskMapController.state, MapCatalogStream.payload) { map, catalog ->
                map to catalog?.takeIf { it.isSuccess }?.items.orEmpty().associate { it.mapId to it.name }
            }.collect { (map, mapNames) ->
                _uiState.update { current ->
                    val snapshot = map.snapshot
                    if (snapshot != null && snapshot.taskId != current.currentTaskId) return@update current
                    current.copy(
                        taskMap = map, mapImageBytes = snapshot?.frame?.imageBytes,
                        mapTransform = snapshot?.frame?.toTaskMapTransform(),
                        mapAvailable = snapshot?.frame != null && snapshot.bitmapSize != null,
                        mapName = loadedMapLabel(
                            snapshot?.frame != null && snapshot.bitmapSize != null,
                            snapshot?.mapId?.takeUnless { it == "LIVE_MAP" } ?: snapshot?.path?.mapId,
                            mapNames
                        ),
                        plannedPath = snapshot?.path
                    )
                }
            }
        }
    }

    fun onCameraClick() {
        _uiState.update { current ->
            val opening = !current.showCameraOverlay
            if (!opening) {
                appState.clearVideoStreamInfo()
            }
            current.copy(
                showCameraOverlay = opening,
                videoStreamUrl = if (opening) {
                    "rtsp://${AppState.DEFAULT_TCP_HOST}:8554/left"
                } else {
                    null
                }
            )
        }
    }

    fun onPauseTaskClick() {
        if (!canSendTaskCommand()) return
        val currentlyPaused = _uiState.value.taskState == DeviceTaskUiState.PAUSED
        val taskId = currentTaskIdOrNull() ?: run {
            ToastUtils.showError("当前任务ID为空")
            return
        }
        val commandType = if (currentlyPaused) {
            PendingTaskCommandType.RESUME
        } else {
            PendingTaskCommandType.PAUSE
        }
        executeTaskCommand(taskId, commandType)
    }

    fun onStartTaskClick() {
        if (!canSendTaskCommand()) return
        val taskId = currentTaskIdOrNull() ?: run {
            ToastUtils.showError("当前任务ID为空")
            return
        }
        executeTaskCommand(taskId, PendingTaskCommandType.START)
    }

    fun onStopTaskClick() {
        runtimeSettingsJob?.cancel()
        _uiState.update { it.copy(runtimeEditor = null, runtimeLoading = false, runtimeApplying = false) }
        val taskId = currentTaskIdOrNull() ?: run {
            ToastUtils.showError("当前任务ID为空")
            return
        }
        executeTaskCommand(taskId, PendingTaskCommandType.STOP)
    }

    private fun refreshRuntimeSettings() {
        val state = _uiState.value
        if (!canEditRuntime(state) || runtimeSettingsJob?.isActive == true ||
            state.runtimeEditor != null) return
        val taskId = state.currentTaskId
        runtimeSettingsJob = viewModelScope.launch {
            val result = tcpManager.executeTaskRuntimeSettings(taskId)
            if (!canEditRuntime(_uiState.value) || _uiState.value.currentTaskId != taskId) return@launch
            val settings = (result as? DeviceCommandResult.Confirmed)?.runtimeSettings
            if (settings?.isUsableFor(taskId) == true) {
                _uiState.update { it.copy(runtimeSettings = settings) }
            }
        }
    }

    fun openRuntimeEditor(field: TaskRuntimeField) {
        val state = _uiState.value
        if (!canEditRuntime(state) || pendingTaskCommands.isNotEmpty() || state.runtimeApplying) return
        val taskId = state.currentTaskId
        runtimeSettingsJob?.cancel()
        _uiState.update { it.copy(runtimeEditor = field, runtimeInput = "", runtimeLoading = true, runtimeError = null) }
        runtimeSettingsJob = viewModelScope.launch {
            val result = tcpManager.executeTaskRuntimeSettings(taskId)
            if (!canEditRuntime(_uiState.value) || _uiState.value.currentTaskId != taskId) return@launch
            val settings = (result as? DeviceCommandResult.Confirmed)?.runtimeSettings
            if (settings?.isUsableFor(taskId) == true) {
                _uiState.update { it.copy(runtimeSettings = settings, runtimeInput = runtimeInput(field, settings), runtimeLoading = false) }
            } else {
                _uiState.update { it.copy(runtimeSettings = null, runtimeLoading = false, runtimeError = runtimeFailure(result)) }
            }
        }
    }

    fun dismissRuntimeEditor() {
        if (!_uiState.value.runtimeApplying) runtimeSettingsJob?.cancel()
        _uiState.update { it.copy(runtimeEditor = null, runtimeLoading = false) }
    }

    fun updateRuntimeInput(value: String) {
        if (_uiState.value.runtimeLoading || _uiState.value.runtimeApplying) return
        _uiState.update { it.copy(runtimeInput = value, runtimeError = null) }
    }

    fun stepRuntimeValue(direction: Int) {
        val state = _uiState.value
        val field = state.runtimeEditor ?: return
        val settings = state.runtimeSettings ?: return
        updateRuntimeInput(stepRuntimeInput(field, state.runtimeInput, direction, settings))
    }

    fun applyRuntimeSettings() {
        val state = _uiState.value
        val field = state.runtimeEditor ?: return
        val settings = state.runtimeSettings ?: return
        if (!canEditRuntime(state) || state.runtimeLoading || state.runtimeApplying || pendingTaskCommands.isNotEmpty()) return
        runtimeInputError(field, state.runtimeInput, settings)?.let { message ->
            _uiState.update { it.copy(runtimeError = message) }
            return
        }
        val taskId = state.currentTaskId
        _uiState.update { it.copy(runtimeApplying = true, runtimeError = null) }
        runtimeSettingsJob = viewModelScope.launch {
            val result = tcpManager.executeTaskRuntimeSettings(
                taskId,
                runSpeed = state.runtimeInput.toFloatOrNull().takeIf { field == TaskRuntimeField.RUN_SPEED },
                discSpeedRpm = state.runtimeInput.toIntOrNull().takeIf { field == TaskRuntimeField.DISC_RPM }
            )
            if (!canEditRuntime(_uiState.value) || _uiState.value.currentTaskId != taskId) return@launch
            val confirmed = (result as? DeviceCommandResult.Confirmed)?.runtimeSettings
            if (confirmed?.isUsableFor(taskId) == true) {
                _uiState.update { it.copy(runtimeSettings = confirmed, runtimeInput = runtimeInput(field, confirmed), runtimeApplying = false) }
                ToastUtils.showSuccess("${field.label}已确认，仅本次任务生效")
            } else {
                val error = runtimeFailure(result)
                _uiState.update { it.copy(runtimeApplying = false, runtimeError = error) }
                ToastUtils.showError(error)
            }
        }
    }

    private fun canEditRuntime(state: DeviceStatusUiState): Boolean =
        canEditTaskRuntime(state.currentTaskId, state.taskState)

    private fun runtimeFailure(result: DeviceCommandResult): String = when (result) {
        is DeviceCommandResult.Confirmed -> "板端未返回有效的临时运行参数，请更新板端"
        is DeviceCommandResult.Rejected -> "设备拒绝调节：${result.message}"
        DeviceCommandResult.SendFailed -> "发送失败，请检查设备连接"
        DeviceCommandResult.TimedOut -> "未收到运行参数回复，请确认板端已更新；重新打开可读取当前值"
    }

    private fun currentTaskIdOrNull(): String? {
        return _uiState.value.currentTaskId.takeIf { it.isNotBlank() }
    }

    /** 页面可见时补取地图与设定值，不开关任务状态上报 collector。 */
    fun setMapVisible(visible: Boolean) {
        taskMapController.setVisible(visible)
        setStatisticsVisible(visible)
        if (visible) {
            if (MapCatalogStream.payload.value?.isSuccess != true) tcpManager.requestMapCatalog()
            if (appState.chassisSettings.value == null) {
                tcpManager.requestSettingRead(readChassis = true, readMap = false, readRpp = false)
            }
            refreshRuntimeSettings()
        }
    }

    /** 重试失败材料，不重置实时轨迹，不触发任何任务执行指令。 */
    fun retryTaskMap() = taskMapController.retry()

    fun dismissNavigationPauseNotice() {
        _uiState.update { it.copy(navigationPauseNotice = null) }
    }

    private fun refreshNavigationPauseNotice() {
        val state = _uiState.value
        val runtime = appState.runtimeTaskState.value
        val notice = navigationPauseTracker.update(
            state.currentTaskId, state.taskState, runtime,
            tcpManager.isConnected() && runtime.receivedAtElapsedMs >= navigationConnectedAtMs
        ) ?: return
        _uiState.update { it.copy(navigationPauseNotice = notice, runtimeEditor = null) }
    }

    override fun onCleared() {
        taskMapController.close()
        statisticsRefreshJob?.cancel()
        statisticsRequestJob?.cancel()
        super.onCleared()
    }

    private fun setStatisticsVisible(visible: Boolean) {
        statisticsVisible = visible
        if (!visible) {
            statisticsRefreshJob?.cancel()
            statisticsRefreshJob = null
            statisticsRequestJob?.cancel()
            return
        }
        if (statisticsRefreshJob?.isActive == true) return
        statisticsRefreshJob = viewModelScope.launch {
            while (isActive) {
                updateStatisticsDisplay()
                refreshStatistics()
                delay(30_000L)
            }
        }
    }

    /** Background reads share the history assembler with record/statistics pages. */
    private fun refreshStatistics() {
        if (!statisticsVisible || statisticsRequestJob?.isActive == true || !tcpManager.isConnected()) return
        statisticsRequestJob = viewModelScope.launch {
            if (!TaskHistoryRequestGate.acquire(this@DeviceStatusViewModel)) return@launch
            try {
                TaskSchedulerStream.resetTaskExecutionHistory()
                val response = withTimeoutOrNull(10_000L) {
                    coroutineScope {
                        // Install the receiver before sending, including for immediate cached replies.
                        val reply = async(start = CoroutineStart.UNDISPATCHED) {
                            TaskSchedulerStream.taskExecutionHistory.filterNotNull().first {
                                it.mapId.isBlank() && it.taskId.isBlank() &&
                                    it.startTime == 0L && it.endTime == 0L
                            }
                        }
                        if (!tcpManager.requestTaskExecutionHistory()) {
                            reply.cancel()
                            null
                        } else reply.await()
                    }
                }
                if (response?.isSuccess == true) {
                    statisticsRecords = response.records
                    statisticsWorkTime = response.workTimeStatistics
                    updateStatisticsDisplay()
                    _uiState.update { it.copy(statisticsError = null) }
                } else {
                    _uiState.update { it.copy(statisticsError = "统计更新失败") }
                    LogUtils.w("DeviceStatistics", response?.message ?: "历史统计请求失败或超时")
                }
            } finally {
                TaskHistoryRequestGate.release(this@DeviceStatusViewModel)
            }
        }
    }

    private fun updateStatisticsDisplay() {
        val records = statisticsRecords ?: return
        val summary = summarizeDeviceStatistics(
            records, System.currentTimeMillis() / 1000L, workTimeStatistics = statisticsWorkTime
        )
        val incomplete = summary.unsettledRecordCount > 0
        _uiState.update {
            it.copy(
                todayAreaText = String.format(Locale.US, "%.2fm²", summary.todayAreaM2),
                totalAreaText = String.format(Locale.US, "%.2fm²", summary.totalAreaM2),
                todayWorkTimeText = formatStatisticsDuration(summary.todayWorkSeconds, incomplete),
                totalWorkTimeText = formatStatisticsDuration(summary.totalWorkSeconds, incomplete),
                statisticsNotice = when {
                    statisticsWorkTime == null -> "需更新板端"
                    statisticsWorkTime?.available != true -> "计时读取异常"
                    incomplete -> "计时不完整"
                    else -> null
                }
            )
        }
    }

    private fun canSendTaskCommand(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastCommandClickAtMs < CLICK_DEBOUNCE_MS) return false
        lastCommandClickAtMs = now
        return true
    }

    private fun executeTaskCommand(taskId: String, commandType: PendingTaskCommandType) {
        if (commandType in pendingTaskCommands) return
        if (commandType != PendingTaskCommandType.STOP && pendingTaskCommands.isNotEmpty()) return
        pendingTaskCommands.add(commandType)
        val generation = ++commandGeneration
        val previousReport = TaskSchedulerStream.taskStatusReport.value
        val (wireCommand, label) = when (commandType) {
            PendingTaskCommandType.START -> SlLink.TaskCommandType.TASK_CMD_START to "开始任务"
            PendingTaskCommandType.STOP -> SlLink.TaskCommandType.TASK_CMD_STOP to "结束任务"
            PendingTaskCommandType.PAUSE -> SlLink.TaskCommandType.TASK_CMD_PAUSE to "暂停任务"
            PendingTaskCommandType.RESUME -> SlLink.TaskCommandType.TASK_CMD_RESUME to "继续任务"
        }
        viewModelScope.launch {
            try {
                ToastUtils.show("$label：等待设备确认")
                val result = tcpManager.executeTaskCommand(wireCommand, taskId)
                // A delayed pause/start reply must never undo a newer stop or a different task.
                if (generation != commandGeneration || taskId != _uiState.value.currentTaskId) return@launch
                when (result) {
                    is DeviceCommandResult.Confirmed -> {
                        val report = TaskSchedulerStream.taskStatusReport.value
                        val terminal = report !== previousReport && report?.taskId == taskId && report.stateValue in setOf(
                            SlLink.TaskState.TASK_STATE_STOPPED_VALUE,
                            SlLink.TaskState.TASK_STATE_COMPLETED_VALUE,
                            SlLink.TaskState.TASK_STATE_ERROR_VALUE
                        )
                        if (!terminal || commandType == PendingTaskCommandType.STOP) {
                            applyTaskCommand(commandType, taskId)
                        }
                        ToastUtils.showSuccess("$label 已确认")
                    }
                    is DeviceCommandResult.Rejected -> ToastUtils.showError("$label 失败：${result.message}")
                    DeviceCommandResult.SendFailed -> ToastUtils.showError("$label 发送失败，请检查连接")
                    DeviceCommandResult.TimedOut -> ToastUtils.showError("$label 未收到确认，请核对设备状态")
                }
            } finally {
                pendingTaskCommands.remove(commandType)
            }
        }
    }

    private fun applyTaskCommand(commandType: PendingTaskCommandType, taskId: String) {
        LogUtils.i("TaskControl", "UI apply action=$commandType taskId=$taskId")
        when (commandType) {
            PendingTaskCommandType.START -> {
                _uiState.update {
                    it.copy(
                        taskState = DeviceTaskUiState.RUNNING,
                        navigationStatus = "研磨中"
                    )
                }
            }
            PendingTaskCommandType.STOP -> {
                trajectoryAccumulator.reset()
                lastTrajectoryReportAtMs = 0L
                taskMapController.onTask(null, 0)
                TaskPathStream.reset(taskId)
                _uiState.update {
                    it.afterTaskStopped()
                }
            }
            PendingTaskCommandType.PAUSE -> {
                _uiState.update {
                    it.copy(
                        taskState = DeviceTaskUiState.PAUSED,
                        navigationStatus = "已暂停"
                    )
                }
            }
            PendingTaskCommandType.RESUME -> {
                _uiState.update {
                    it.copy(
                        taskState = DeviceTaskUiState.RUNNING,
                        navigationStatus = "研磨中"
                    )
                }
            }
        }
    }

    private fun DeviceTaskUiState.navigationLabel(): String = when (this) {
        DeviceTaskUiState.IDLE -> "空闲"
        DeviceTaskUiState.READY -> "待开始"
        DeviceTaskUiState.RUNNING -> "研磨中"
        DeviceTaskUiState.PAUSED -> "已暂停"
    }

    private fun formatAreaM2(value: Float): String {
        return "%.2fm²".format(value.coerceAtLeast(0f))
    }

    private fun formatRemainTimeS(value: Float): String {
        if (!value.isFinite()) return "未知"
        val seconds = value.coerceAtLeast(0f).toLong()
        return if (seconds < 60L) "${seconds}秒" else formatStatisticsDuration(seconds)
    }

    private fun com.sinelynx.grindingrobot.core.model.state.TaskStatusReportPayload.toPoseItem(): TaskPoseUiItem? {
        val x = positionX ?: return null
        val y = positionY ?: return null
        return TaskPoseUiItem(
            x = x,
            y = y,
            headingDeg = headingDeg ?: 0f,
            lineColorArgb = currentRegionRepeatIndex.toTrajectoryLineColorArgb()
        )
    }

    private fun Int.toTrajectoryLineColorArgb(): Int {
        return when (this) {
            in Int.MIN_VALUE..1 -> 0xFFFAE051.toInt()
            2 -> 0xFF54DD83.toInt()
            3 -> 0xFF41D3BF.toInt()
            4 -> 0xFF4881F4.toInt()
            5 -> 0xFF8A5AEF.toInt()
            6 -> 0xFFA755F4.toInt()
            else -> 0xFFE34544.toInt()
        }
    }

    private fun com.sinelynx.grindingrobot.core.model.state.TaskStatusReportPayload.toTaskUiState(): DeviceTaskUiState {
        return when (stateValue) {
            SlLink.TaskState.TASK_STATE_READY_VALUE -> DeviceTaskUiState.READY
            SlLink.TaskState.TASK_STATE_PLANNING_VALUE,
            SlLink.TaskState.TASK_STATE_RUNNING_VALUE -> DeviceTaskUiState.RUNNING
            SlLink.TaskState.TASK_STATE_PAUSED_VALUE -> DeviceTaskUiState.PAUSED
            else -> DeviceTaskUiState.IDLE
        }
    }

    private fun MapImagePayload.toTaskMapTransform(): TaskMapTransformUiState? {
        if (!hasDisplayGeometry()) return null
        return TaskMapTransformUiState(
            width = mapWidth,
            height = mapHeight,
            resolution = resolution,
            originX = originX,
            originY = originY,
            headingDeg = headingDeg,
            previewScaleX = previewScaleX,
            previewScaleY = previewScaleY,
            alignmentYawDeg = alignmentYawDeg,
            rotationAlignmentDeltaDeg = rotationAlignmentDeltaDeg
        )
    }

}
